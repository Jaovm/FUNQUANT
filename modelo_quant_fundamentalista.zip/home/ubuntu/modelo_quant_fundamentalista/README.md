# Modelo Quantitativo e Fundamentalista para Análise de Investimentos

## Visão Geral

Este projeto consiste em um conjunto de scripts Python desenvolvidos para realizar análises quantitativas e fundamentalistas de ativos financeiros, realizar backtests de estratégias, gerar recomendações de investimento e otimizar carteiras. A estrutura foi pensada para ser modular, permitindo a integração com uma interface de usuário como o Streamlit (a ser desenvolvida pelo usuário).

## Estrutura do Projeto

O projeto está organizado da seguinte forma:

```
/modelo_quant_fundamentalista
|-- /data/                  # Diretório para armazenar dados brutos, processados e resultados
|   |-- br_PETR4_SA_chart.json
|   |-- br_PETR4_SA_insights.json
|   |-- br_PETR4_SA_quant_analysis.csv
|   |-- br_PETR4_SA_sma_crossover_backtest.png
|   |-- br_PETR4_SA_sma_crossover_stats.csv
|   |-- us_AAPL_chart.json
|   |-- us_AAPL_insights.json
|   |-- us_AAPL_quant_analysis.csv
|   |-- us_AAPL_sma_crossover_backtest.png
|   |-- us_AAPL_sma_crossover_stats.csv
|   |-- optimized_portfolio_max_sharpe.json
|   |-- optimized_portfolio_min_volatility.json
|   |-- recomendacoes_geradas.json
|   |-- (outros arquivos de dados macroeconômicos, se a coleta for bem-sucedida)
|-- /src/                   # Diretório com os scripts Python dos módulos
|   |-- app.py              # Estrutura básica para a aplicação Streamlit (inicial)
|   |-- coleta_dados.py     # Módulo para coleta de dados financeiros e macroeconômicos
|   |-- analise_quantitativa.py # Módulo para cálculos de indicadores quantitativos
|   |-- analise_fundamentalista.py # Módulo para processamento de dados fundamentalistas
|   |-- backtest_module.py  # Módulo para execução de backtests de estratégias
|   |-- recomendacoes_module.py # Módulo para geração de recomendações
|   |-- otimizacao_carteira.py # Módulo para otimização de carteira e sugestão de aportes
|-- /venv/                  # Ambiente virtual Python com as dependências
|-- todo.md                 # Checklist do desenvolvimento do projeto
|-- README.md               # Este arquivo
```

## Funcionalidades Implementadas

1.  **Coleta de Dados (`coleta_dados.py`):**
    *   Busca dados históricos de preços e informações de empresas utilizando a API `YahooFinance/get_stock_chart` e `YahooFinance/get_stock_insights`.
    *   Tentativa de coleta de dados macroeconômicos (ex: inflação, PIB) utilizando a API `DataBank` (atualmente com limitações devido a possíveis restrições de API key/rate limit no ambiente de desenvolvimento; o código está preparado para usar os dados se disponíveis).
    *   Salva os dados brutos em formato JSON e CSV no diretório `/data/`.

2.  **Análise Quantitativa (`analise_quantitativa.py`):**
    *   Carrega os dados históricos de preços.
    *   Calcula indicadores técnicos como Médias Móveis Simples (SMA 50, SMA 200) e Índice de Força Relativa (RSI 14).
    *   Salva os dados enriquecidos com os indicadores em formato CSV.

3.  **Análise Fundamentalista (`analise_fundamentalista.py`):**
    *   Carrega os dados de insights das empresas (JSON).
    *   Extrai e exibe informações relevantes como setor, métricas de valuation (se disponíveis na API), e recomendações de analistas.
    *   Os dados fundamentalistas detalhados podem ser limitados pela API utilizada.

4.  **Backtesting (`backtest_module.py`):**
    *   Utiliza a biblioteca `bt` para realizar backtests.
    *   Implementa uma estratégia de exemplo baseada no cruzamento de médias móveis (SMA 50 vs SMA 200).
    *   Gera e salva gráficos de desempenho e estatísticas do backtest (ex: Retorno Total, Sharpe Ratio, Drawdown Máximo) no diretório `/data/`.

5.  **Recomendações (`recomendacoes_module.py`):**
    *   Analisa um cenário macroeconômico simplificado (com base nos dados macroeconômicos disponíveis).
    *   Combina informações da análise quantitativa (RSI), fundamentalista (rating de analistas) e o cenário macro para gerar um score de recomendação.
    *   Gera recomendações de "Comprar", "Manter/Neutro" ou "Vender/Evitar" para os ativos analisados.
    *   Salva as recomendações em formato JSON.

6.  **Otimização de Carteira (`otimizacao_carteira.py`):**
    *   Utiliza a biblioteca `PyPortfolioOpt`.
    *   Carrega os preços históricos dos ativos recomendados.
    *   Implementa duas estratégias de otimização: Maximização do Índice de Sharpe e Mínima Volatilidade.
    *   Calcula os pesos ótimos para a carteira e exibe a performance esperada.
    *   Fornece uma sugestão de como alocar um novo aporte para atingir os pesos ótimos, considerando uma carteira atual simulada.
    *   Salva os resultados da otimização (pesos e performance) em formato JSON.

## Como Configurar e Executar

1.  **Ambiente Virtual e Dependências:**
    *   O projeto já inclui um ambiente virtual (`venv`) com as dependências instaladas durante o desenvolvimento. As principais dependências são: `streamlit`, `pandas`, `numpy`, `yfinance` (indiretamente via API), `matplotlib`, `seaborn`, `plotly`, `scipy`, `bt`, `PyPortfolioOpt`.
    *   Para recriar o ambiente ou instalar em um novo, você pode usar o `pip` com os nomes das bibliotecas mencionadas. Um arquivo `requirements.txt` pode ser gerado a partir do `venv` se necessário (`pip freeze > requirements.txt` dentro do ambiente ativado).

2.  **Execução dos Módulos Individuais:**
    *   Cada script Python no diretório `src/` pode ser executado individualmente para testar sua funcionalidade específica. Eles geralmente contêm uma seção `if __name__ == "__main__":` com exemplos de uso.
    *   Exemplo para executar o módulo de coleta de dados:
        ```bash
        /caminho/para/modelo_quant_fundamentalista/venv/bin/python3 /caminho/para/modelo_quant_fundamentalista/src/coleta_dados.py
        ```
    *   Recomenda-se executar os scripts na seguinte ordem para garantir que os dados dependentes estejam disponíveis:
        1.  `coleta_dados.py`
        2.  `analise_quantitativa.py`
        3.  `analise_fundamentalista.py` (pode ser executado após `coleta_dados.py`)
        4.  `backtest_module.py` (depende de `analise_quantitativa.py`)
        5.  `recomendacoes_module.py` (depende de `analise_quantitativa.py`, `analise_fundamentalista.py` e opcionalmente `coleta_dados.py` para macro)
        6.  `otimizacao_carteira.py` (depende de `analise_quantitativa.py` e `recomendacoes_module.py`)

3.  **Integração com Streamlit (`app.py`):**
    *   O arquivo `src/app.py` contém uma estrutura básica inicial para uma aplicação Streamlit.
    *   **Esta parte do desenvolvimento (a interface Streamlit completa) ficou a cargo do usuário.**
    *   Para desenvolver a interface, você precisará importar as funções dos módulos desenvolvidos em `app.py` e criar os elementos de UI (seletores, botões, gráficos, tabelas) para interagir com eles e exibir os resultados.
    *   Para executar a aplicação Streamlit (após desenvolvê-la):
        ```bash
        /caminho/para/modelo_quant_fundamentalista/venv/bin/streamlit run /caminho/para/modelo_quant_fundamentalista/src/app.py
        ```

## Limitações e Pontos de Atenção

*   **Dados Macroeconômicos:** A coleta de dados macroeconômicos via API `DataBank` pode estar sujeita a limitações de acesso (API keys, rate limits) no ambiente de desenvolvimento. O módulo `recomendacoes_module.py` usa uma análise simplificada caso esses dados não estejam disponíveis. Para uma análise mais robusta, garanta o acesso e a atualização regular desses dados.
*   **Dados Fundamentalistas:** A profundidade dos dados fundamentalistas obtidos pela API `YahooFinance/get_stock_insights` pode ser limitada. Para análises fundamentalistas mais aprofundadas, pode ser necessário integrar outras fontes de dados.
*   **APIs de Dados:** A disponibilidade e os termos de uso das APIs podem mudar. É importante monitorar e adaptar o código de coleta de dados conforme necessário.
*   **Interface Streamlit:** A interface de usuário completa com Streamlit não foi implementada como parte deste escopo e deve ser desenvolvida pelo usuário, utilizando os módulos fornecidos.
*   **Exemplos de Ativos:** Os scripts utilizam `PETR4.SA` e `AAPL` como exemplos. Para analisar outros ativos, modifique os tickers nos scripts ou, idealmente, na interface Streamlit que será desenvolvida.
*   **Robustez da Otimização:** A otimização de carteira é mais robusta e significativa com um número maior de ativos e um histórico de dados mais longo e consistente. Os exemplos com poucos ativos servem para demonstrar a funcionalidade.
*   **Estratégias de Backtest:** Apenas uma estratégia de exemplo (cruzamento de médias móveis) foi implementada no `backtest_module.py`. O sistema foi projetado para permitir a adição de outras estratégias.

## Próximos Passos Sugeridos (para o usuário)

1.  **Desenvolver a Interface Streamlit:** Criar a interface em `src/app.py` para permitir que o usuário:
    *   Selecione ativos para análise.
    *   Dispare a coleta e processamento de dados.
    *   Visualize os resultados das análises quantitativa e fundamentalista.
    *   Configure e execute backtests, visualizando os resultados.
    *   Veja as recomendações geradas.
    *   Insira a carteira atual e o valor do aporte.
    *   Escolha o método de otimização e visualize a carteira otimizada e as sugestões de aporte.
2.  **Expandir Fontes de Dados:** Integrar fontes adicionais para dados fundamentalistas e macroeconômicos mais detalhados.
3.  **Desenvolver Novas Estratégias:** Adicionar mais estratégias de investimento no módulo de backtest.
4.  **Refinar Lógica de Recomendação:** Aprimorar o sistema de scoring e os critérios para recomendações.
5.  **Testes Exaustivos:** Realizar testes mais abrangentes com diferentes ativos, períodos e cenários.

Este projeto fornece uma base sólida para um sistema de análise de investimentos. Com o desenvolvimento da interface Streamlit e potenciais expansões, ele pode se tornar uma ferramenta poderosa para tomada de decisão.
